package com.shoaib.courier;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int ink = Color.rgb(10, 61, 46), green = Color.rgb(15,107,70), pale = Color.rgb(240,253,244);
    private DB db; private LinearLayout root, content; private String page = "Bookings";

    @Override public void onCreate(Bundle state) { super.onCreate(state); db = new DB(); showHome(); }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(ink); if (bold) t.setTypeface(null, Typeface.BOLD); t.setPadding(dp(2),dp(5),dp(2),dp(5)); return t; }
    private Button button(String s, Runnable r) { Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(v -> r.run()); return b; }
    private EditText field(String hint) { EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextSize(15); e.setPadding(dp(12),dp(8),dp(12),dp(8)); return e; }
    private void showHome() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(18),dp(18),dp(18),dp(12)); header.setBackgroundColor(green);
        TextView title = new TextView(this); title.setText("📦 ParcelGo"); title.setTextSize(24); title.setTypeface(null,Typeface.BOLD); title.setTextColor(Color.WHITE);
        TextView sub = new TextView(this); sub.setText("FAST. SAFE. DELIVERED. · OFFLINE TEST VERSION"); sub.setTextSize(10); sub.setTextColor(Color.WHITE); sub.setPadding(0,dp(4),0,0);
        header.addView(title); header.addView(sub); root.addView(header);
        LinearLayout nav = new LinearLayout(this); nav.setPadding(dp(5),dp(3),dp(5),dp(3)); nav.setBackgroundColor(pale);
        for (String p : new String[]{"Bookings","Add Parcel","Riders","Reports"}) { Button b = new Button(this); b.setText(p); b.setTextSize(11); b.setAllCaps(false); b.setPadding(dp(2),0,dp(2),0); b.setOnClickListener(v -> { page=p; render(); }); nav.addView(b,new LinearLayout.LayoutParams(0,dp(48),1)); }
        root.addView(nav); ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16),dp(12),dp(16),dp(24)); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root); render();
    }
    private void render() { content.removeAllViews(); if (page.equals("Add Parcel")) addForm(); else if (page.equals("Riders")) ridersPage(); else if (page.equals("Reports")) reportsPage(); else bookingsPage(); }
    private void addLabel(String s) { content.addView(text(s,14,true)); }
    private void addForm() {
        content.addView(text("Create a booking",22,true)); content.addView(text("Enter test details. Required fields are marked *.",13,false));
        EditText sender=field("Sender name *"), senderPhone=field("Sender phone"), pickup=field("Pickup address *"), receiver=field("Receiver name *"), receiverPhone=field("Receiver phone"), destination=field("Delivery address *"), parcel=field("Parcel description / type"), charge=field("Delivery charge (₹) e.g. 120");
        for (EditText e : new EditText[]{sender,senderPhone,pickup,receiver,receiverPhone,destination,parcel,charge}) { content.addView(e); }
        Spinner payment = new Spinner(this); payment.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Payment: Unpaid","Payment: Paid","Payment: Cash on delivery"})); content.addView(payment);
        Button save=button("Save Parcel Booking",()->{
            if (sender.getText().toString().trim().isEmpty() || pickup.getText().toString().trim().isEmpty() || receiver.getText().toString().trim().isEmpty() || destination.getText().toString().trim().isEmpty()) { Toast.makeText(this,"Please fill sender, receiver and both addresses.",Toast.LENGTH_LONG).show(); return; }
            double amount=0; try { amount=Double.parseDouble(charge.getText().toString().trim().isEmpty()?"0":charge.getText().toString().trim()); if(amount<0) throw new NumberFormatException(); } catch(Exception ex) { Toast.makeText(this,"Enter a valid non-negative delivery charge.",Toast.LENGTH_LONG).show(); return; }
            ContentValues v=new ContentValues(); v.put("sender",sender.getText().toString().trim()); v.put("sender_phone",senderPhone.getText().toString().trim()); v.put("pickup",pickup.getText().toString().trim()); v.put("receiver",receiver.getText().toString().trim()); v.put("receiver_phone",receiverPhone.getText().toString().trim()); v.put("destination",destination.getText().toString().trim()); v.put("parcel",parcel.getText().toString().trim()); v.put("charge",amount); v.put("payment",payment.getSelectedItem().toString().replace("Payment: ","")); v.put("status","Booked"); v.put("rider_id",0); v.put("created",System.currentTimeMillis()); db.getWritableDatabase().insert("parcels",null,v); Toast.makeText(this,"Booking saved on this phone",Toast.LENGTH_SHORT).show(); page="Bookings"; render();
        }); save.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green)); save.setTextColor(Color.WHITE); content.addView(save);
    }
    private void bookingsPage() {
        content.addView(text("Parcel bookings",22,true)); content.addView(text("Tap a booking to update its status or delete it.",13,false));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT p.*, r.name AS rider_name FROM parcels p LEFT JOIN riders r ON p.rider_id=r.id ORDER BY p.id DESC",null); int count=0;
        while(c.moveToNext()) { count++; final long id=c.getLong(c.getColumnIndexOrThrow("id")); String code=String.format(Locale.US,"PC-%04d",id); String status=c.getString(c.getColumnIndexOrThrow("status")); String rider=c.getString(c.getColumnIndexOrThrow("rider_name")); if(rider==null) rider="Not assigned";
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(12),dp(10),dp(12),dp(8)); card.setBackgroundColor(pale); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,dp(7),0,dp(7)); content.addView(card,cp);
            card.addView(text(code+"  ·  "+status,17,true)); card.addView(text(c.getString(c.getColumnIndexOrThrow("sender"))+" → "+c.getString(c.getColumnIndexOrThrow("receiver")),15,true)); card.addView(text("From: "+c.getString(c.getColumnIndexOrThrow("pickup")),13,false)); card.addView(text("To: "+c.getString(c.getColumnIndexOrThrow("destination")),13,false)); card.addView(text("Charge: "+money(c.getDouble(c.getColumnIndexOrThrow("charge")))+" · "+c.getString(c.getColumnIndexOrThrow("payment")),13,false)); card.addView(text("Rider: "+rider,13,false)); card.addView(button("Manage booking",()->manageParcel(id)));
        } c.close(); if(count==0) { content.addView(text("No bookings yet",18,true)); content.addView(text("Tap Add Parcel to create your first test booking.",14,false)); }
    }
    private String money(double n) { return NumberFormat.getCurrencyInstance(new Locale("en","IN")).format(n); }
    private void manageParcel(long id) {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT status,rider_id FROM parcels WHERE id=?",new String[]{String.valueOf(id)}); if(!c.moveToFirst()){c.close();return;} String current=c.getString(0); long riderId=c.getLong(1); c.close();
        String[] statuses={"Booked","Accepted","Picked Up","In Transit","Delivered","Cancelled"}; int selected=0; for(int i=0;i<statuses.length;i++)if(statuses[i].equals(current))selected=i;
        Spinner st=new Spinner(this); st.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,statuses)); st.setSelection(selected);
        Cursor rc=db.getReadableDatabase().rawQuery("SELECT id,name FROM riders ORDER BY name",null); java.util.ArrayList<String> names=new java.util.ArrayList<>(); java.util.ArrayList<Long> ids=new java.util.ArrayList<>(); names.add("Unassigned");ids.add(0L);while(rc.moveToNext()){ids.add(rc.getLong(0));names.add(rc.getString(1));}rc.close();Spinner rs=new Spinner(this);rs.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));for(int i=0;i<ids.size();i++)if(ids.get(i)==riderId)rs.setSelection(i);
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(16),dp(8),dp(16),0);box.setOrientation(LinearLayout.VERTICAL);box.addView(text("Delivery status",14,true));box.addView(st);box.addView(text("Assign rider",14,true));box.addView(rs);
        new AlertDialog.Builder(this).setTitle("Manage PC-"+String.format(Locale.US,"%04d",id)).setView(box).setPositiveButton("Save",(d,w)->{ContentValues v=new ContentValues();v.put("status",st.getSelectedItem().toString());v.put("rider_id",ids.get(rs.getSelectedItemPosition()));db.getWritableDatabase().update("parcels",v,"id=?",new String[]{String.valueOf(id)});render();}).setNeutralButton("Delete",(d,w)->new AlertDialog.Builder(this).setTitle("Delete booking?").setMessage("This permanently deletes this local test booking.").setNegativeButton("Keep",null).setPositiveButton("Delete",(dd,ww)->{db.getWritableDatabase().delete("parcels","id=?",new String[]{String.valueOf(id)});render();}).show()).setNegativeButton("Cancel",null).show();
    }
    private void ridersPage() {
        content.addView(text("Delivery partners",22,true)); EditText name=field("Rider full name *"),phone=field("Rider phone number"),vehicle=field("Vehicle / notes (e.g. bike)"); content.addView(name);content.addView(phone);content.addView(vehicle);
        content.addView(button("Save Rider",()->{if(name.getText().toString().trim().isEmpty()){Toast.makeText(this,"Enter rider name",Toast.LENGTH_SHORT).show();return;}ContentValues v=new ContentValues();v.put("name",name.getText().toString().trim());v.put("phone",phone.getText().toString().trim());v.put("vehicle",vehicle.getText().toString().trim());db.getWritableDatabase().insert("riders",null,v);render();Toast.makeText(this,"Rider saved",Toast.LENGTH_SHORT).show();}));
        content.addView(text("Saved riders",18,true)); Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,phone,vehicle FROM riders ORDER BY id DESC",null);int n=0;while(c.moveToNext()){n++;long id=c.getLong(0);content.addView(text(c.getString(1)+"\n"+c.getString(2)+"\n"+c.getString(3),15,false));content.addView(button("Delete rider",()->new AlertDialog.Builder(this).setTitle("Delete rider?").setMessage("Existing bookings will become unassigned if you delete this rider.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{ContentValues v=new ContentValues();v.put("rider_id",0);db.getWritableDatabase().update("parcels",v,"rider_id=?",new String[]{String.valueOf(id)});db.getWritableDatabase().delete("riders","id=?",new String[]{String.valueOf(id)});render();}).show()));content.addView(text("────────────",12,false));}c.close();if(n==0)content.addView(text("No riders saved yet.",14,false));
    }
    private void reportsPage() {
        content.addView(text("Reports",22,true)); SQLiteDatabase d=db.getReadableDatabase(); addMetric("Total bookings",scalar(d,"SELECT COUNT(*) FROM parcels"));addMetric("Delivered",scalar(d,"SELECT COUNT(*) FROM parcels WHERE status='Delivered'"));addMetric("In progress",scalar(d,"SELECT COUNT(*) FROM parcels WHERE status IN ('Accepted','Picked Up','In Transit')"));addMetric("Cancelled",scalar(d,"SELECT COUNT(*) FROM parcels WHERE status='Cancelled'")); Cursor c=d.rawQuery("SELECT COALESCE(SUM(charge),0),COALESCE(SUM(CASE WHEN payment='Paid' THEN charge ELSE 0 END),0),COALESCE(SUM(CASE WHEN payment!='Paid' THEN charge ELSE 0 END),0) FROM parcels WHERE status!='Cancelled'",null);if(c.moveToFirst()){addMetric("Charges on active/completed bookings",money(c.getDouble(0)));addMetric("Marked paid",money(c.getDouble(1)));addMetric("Not marked paid",money(c.getDouble(2)));}c.close();content.addView(text("These are simple local test totals, not accounting or tax reports.",12,false));
    }
    private String scalar(SQLiteDatabase d,String q){Cursor c=d.rawQuery(q,null);String s=c.moveToFirst()?c.getString(0):"0";c.close();return s;}
    private void addMetric(String label,String value){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(8),dp(12),dp(8));card.setBackgroundColor(pale);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));content.addView(card,p);card.addView(text(label,13,false));card.addView(text(value,21,true));}
    private class DB extends SQLiteOpenHelper {
        DB(){super(MainActivity.this,"parcel_courier_test.db",null,1);} public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE parcels (id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT NOT NULL,sender_phone TEXT,pickup TEXT NOT NULL,receiver TEXT NOT NULL,receiver_phone TEXT,destination TEXT NOT NULL,parcel TEXT,charge REAL NOT NULL DEFAULT 0,payment TEXT NOT NULL,status TEXT NOT NULL,rider_id INTEGER NOT NULL DEFAULT 0,created INTEGER NOT NULL)");d.execSQL("CREATE TABLE riders (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,vehicle TEXT)");}public void onUpgrade(SQLiteDatabase d,int oldV,int newV){}
    }
}
