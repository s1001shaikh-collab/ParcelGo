# ParcelGo — Fast. Safe. Delivered.

Free personal-use Android parcel/courier test app. This version is local-only: bookings and riders are stored on the device using SQLite. No online accounts, cloud sync, SMS, payments, or live GPS tracking.

## Build

The GitHub Actions workflow builds a debug APK using Java 17 and Gradle 8.9. The generated APK is a test build, not a Play Store release.

## Features
- Create and review parcel bookings
- Record sender and receiver details, addresses, parcel description, charge and payment status
- Assign local delivery partners
- Update status: Booked, Accepted, Picked Up, In Transit, Delivered, Cancelled
- View basic booking/payment reports
- Data stored locally on this device

## Branding
- App name: ParcelGo
- Tagline: Fast. Safe. Delivered.
- Palette: forest green and white with bright green accents
